require 'spec_helper'
# Rename this file to classname_spec.rb
# Check other boxen modules for examples
# or read http://rspec-puppet.com/tutorial/
describe 'xmind' do
  it { should contain_class('Xmind') }
  it { should contain_package('Xmind').with_provider('appdmg_eula') }
  it { should contain_package('Xmind').with_source('http://www.xmind.net/xmind/downloads/xmind-macosx-3.4.1.201401221918.dmg') }
end
