require 'spec_helper'

describe 'balsamiq_mockups' do
  it do
    should contain_class('balsamiq_mockups')
    should contain_package('balsamiq-mockups').with({
    'provider'        => 'brewcask',
    'install_options' => '--appdir=/Applications'
    })
  end
end
