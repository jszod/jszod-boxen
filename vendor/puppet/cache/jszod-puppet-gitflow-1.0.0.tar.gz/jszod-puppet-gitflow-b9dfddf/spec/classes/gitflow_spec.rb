require 'spec_helper'
describe 'gitflow' do

  let(:pre_condition) { "class homebrew {}" }
  
  it { should contain_class('gitflow') }
  it { should contain_package('git-flow') }

end
