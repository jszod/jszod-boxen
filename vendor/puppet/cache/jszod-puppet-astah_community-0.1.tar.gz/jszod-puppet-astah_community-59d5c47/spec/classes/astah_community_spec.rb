require 'spec_helper'
# Rename this file to classname_spec.rb
# Check other boxen modules for examples
# or read http://rspec-puppet.com/tutorial/
describe 'astah_community' do
  it { should contain_class('astah_community') }
  it { should contain_package('astah_community').with_provider('appdmg_eula') }
  it { should contain_package('astah_community').with_source('http://cdn.change-vision.com/files/astah-community-6_8_0-35584d-MacOs.dmg')}
end
