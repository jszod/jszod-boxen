# Syncplicity Module for Boxen

Installs [Syncplicity](http://www.syncpliciy.com), a file synchronization and sharing application.

[![Build Status](https://travis-ci.org/jszod/puppet-syncplicity.svg?branch=master)](https://travis-ci.org/jszod/puppet-syncplicity)

## Usage

```puppet
include syncplicity
```

## Required Puppet Modules

* `boxen`

