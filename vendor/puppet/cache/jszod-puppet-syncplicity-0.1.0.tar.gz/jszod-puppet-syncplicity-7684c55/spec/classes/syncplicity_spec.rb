require 'spec_helper'
# Rename this file to classname_spec.rb
# Check other boxen modules for examples
# or read http://rspec-puppet.com/tutorial/
describe 'syncplicity' do
  it { should contain_class('Syncplicity') }
  it { should contain_package('Syncplicity').with_provider('appdmg_eula') }
  it { should contain_package('Syncplicity').with_source('http://download.syncplicity.com/mac/Syncplicity.dmg') }
end
