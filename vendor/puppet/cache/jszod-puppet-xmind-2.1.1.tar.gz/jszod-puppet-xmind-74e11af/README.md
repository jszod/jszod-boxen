# Puppet Module for Xmind

Installs [XMind](http://www.xmind.net), a  mind mapping applicaion for Mac OS X.

[![Build Status](https://travis-ci.org/jszod/puppet-xmind.png)](https://travis-ci.org/jszod/puppet-xmind#)

## Usage

```puppet
include xmind
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `brewcask`

