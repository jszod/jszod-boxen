require 'spec_helper'

describe 'xmind' do
  it do
    should contain_class('xmind')
    should contain_package('xmind').with({
    'provider'        => 'brewcask',
    'install_options' => '--appdir=/Applications' 
    })
  end
end
